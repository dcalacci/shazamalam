shazamalam
==========

Team Members:
- Dan Calacci	(calacci.d@husky.neu.edu)
- Lucas Haber	(haber.l@husky.neu.edu)
- Eric Peterson (peterson.er@husky.neu.edu)
- Talia Swartz	(swartz.t@husky.neu.edu)


Once the tar.gz has been unzipped, navigate to the 
directory containing its contents and run this 
command to create the executable:

> chmod +x dan

After that ./dan should be available from this
directory as defined at:

http://www.ccs.neu.edu/course/cs4500f14/assignment4.txt

The only third party software used is the standard
python libraries found on the CCIS Linux machines




